DragandMove.py  运行后可以对机械臂进行拖拽
follow_traj.py 机械臂会重复对record.npy中记录的轨迹，期间受力可以被打断和拖拽
drag_and_repeat.py 运行后拖拽机械臂，机械臂记录运动轨迹然后重复

record.npy预先记录下来的，一个运动轨迹中每个关节的数据



代码通过kortexAPI实现，如要运行，需要配置kortex API环境。