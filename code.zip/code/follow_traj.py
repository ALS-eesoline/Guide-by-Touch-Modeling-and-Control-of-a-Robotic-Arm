#! /usr/bin/env python3

###
# KINOVA (R) KORTEX (TM)
#
# Copyright (c) 2018 Kinova inc. All rights reserved.
#
# This software may be modified and distributed
# under the terms of the BSD 3-Clause license.
#
# Refer to the LICENSE file for details.
#
###

import sys
import os
import time
import threading
from kortex_api.autogen.client_stubs.BaseClientRpc import BaseClient
from kortex_api.autogen.client_stubs.BaseCyclicClientRpc import BaseCyclicClient
import numpy as np
np.set_printoptions(precision=3, suppress=True)

from kortex_api.autogen.messages import Session_pb2, Base_pb2, BaseCyclic_pb2
from kortex_api.autogen.client_stubs.BaseClientRpc import BaseClient
from kortex_api.autogen.client_stubs.DeviceManagerClientRpc import DeviceManagerClient
from kortex_api.autogen.client_stubs.DeviceConfigClientRpc import DeviceConfigClient

from kortex_api.autogen.messages import Session_pb2, Base_pb2, Common_pb2

# Maximum allowed waiting time during actions (in seconds)
TIMEOUT_DURATION = 20

# Actuator speed (deg/s)
SPEED = 20.0


dh_params = [
    # [0.0, np.pi, 0.0, 0],
    [0.0, np.pi / 2, -(0.1564 + 0.1284), 0.0],
    [0.0, np.pi / 2, -(0.0054 + 0.0064), np.pi],
    [0.0, np.pi / 2, -(0.2104 + 0.2104), np.pi],
    [0.0, np.pi / 2, -(0.0064 + 0.0064), np.pi],
    [0.0, np.pi / 2, -(0.2084 + 0.1059), np.pi],
    [0.0, np.pi / 2, 0.0, np.pi],
    [0.0, np.pi, -(0.1059 + 0.0615), np.pi]
]

inertial_params = [
    {'mass': 1.697, 'com': [-0.000648, -0.000166, 0.084487], 'Ixx': 0.004622, 'Iyy': 0.004495, 'Izz': 0.002079,
     'Ixy': 0.000009, 'Ixz': 0.000060, 'Iyz': 0.000009},
    # Add parameters for each link
    {'mass': 1.377, 'com': [-0.000023, -0.010364, -0.073360], 'Ixx': 0.004570, 'Iyy': 0.004831, 'Izz': 0.001409,
     'Ixy': 0.000001, 'Ixz': 0.000002, 'Iyz': 0.000448},
    {'mass': 1.262, 'com': [0.000035, -0.208207, -0.018890], 'Ixx': 0.046752, 'Iyy': 0.000850, 'Izz': 0.047188,
     'Ixy': -0.000009, 'Ixz': 0.0, 'Iyz': -0.000098},
    {'mass': 0.930, 'com': [0.000018, 0.076168, -0.01397], 'Ixx': 0.008292, 'Iyy': 0.000628, 'Izz': 0.008464,
     'Ixy': -0.000001, 'Ixz': 0.0, 'Iyz': 0.000432},
    {'mass': 0.678, 'com': [-0.000001, 0.008466, -0.062937], 'Ixx': 0.001645, 'Iyy': 0.001666, 'Izz': 0.000389,
     'Ixy': 0.0, 'Ixz': 0.0, 'Iyz': -0.000234},
    {'mass': 0.678, 'com': [-0.000001, 0.046429, -0.008704], 'Ixx': 0.001685, 'Iyy': 0.0004, 'Izz': 0.001696,
     'Ixy': 0.0, 'Ixz': 0.0, 'Iyz': 0.000255},
    # {'mass': 1.9, 'com': [0.000281, 0.011402, -0.029798], 'Ixx': 0.000587, 'Iyy': 0.000369, 'Izz': 0.000609,
    #  'Ixy': 0.000003, 'Ixz': 0.000003, 'Iyz': -0.000118}
    {'mass': 1.68, 'com': [0.000281, 0.011402, 0.02], 'Ixx': 0.000587, 'Iyy': 0.000369, 'Izz': 0.000609,
     'Ixy': 0.000003, 'Ixz': 0.000003, 'Iyz': -0.000118}
]
def normalization_to_neg_pos_pi(x):
    x = x - 2 * 180 * np.floor((x + 180) / 360)
    return x

def transformation_matrix(a, alpha, d, theta):
    """ Compute the transformation matrix from DH parameters """
    T = np.array([
        [np.cos(theta), -np.sin(theta) * np.cos(alpha), np.sin(theta) * np.sin(alpha), a * np.cos(theta)],
        [np.sin(theta), np.cos(theta) * np.cos(alpha), -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
        [0, np.sin(alpha), np.cos(alpha), d],
        [0, 0, 0, 1]
    ])
    return T


def compute_jacobians(dh_params, q, com_positions):
    """ Compute the Jacobian matrices for each link """
    n = len(dh_params)
    Jv = np.zeros((3, n, n))  # Linear velocity Jacobians
    Jw = np.zeros((3, n, n))  # Angular velocity Jacobians

    T_series_for_Jv = []

    T = np.eye(4)  # Initial transformation matrix
    # T[2, 3] = -0.13
    T = T @ transformation_matrix(0, np.pi, 0, 0)
    # print(T)

    T_series_for_Jv.append(T.copy())

    z = np.array([0, 0, 1])  # Axis of rotation for revolute joints

    # Transformation matrices and positions
    T_matrices = []
    p_matrices = []

    for i in range(n):
        a, alpha, d, theta = dh_params[i]
        # theta += q[i][0]  # Add the current joint angl

        T_i = transformation_matrix(a, alpha, d, theta + q[i][0])
        T = T @ T_i

        T_series_for_Jv.append(T.copy())
        T_matrices.append(T.copy())
        p_matrices.append(T[:3, 3])  # 每个坐标系原点的世界坐标

    # Compute Jacobians
    for i in range(n):  # i-th link
        T_i = T_matrices[i]
        R = T_i[:3, :3]
        p = T_i[:3, 3]
        com_position = R @ com_positions[i] + p  # Transform COM position to world frame

        for j in range(i + 1):
            T_j = T_series_for_Jv[j]
            z_j = T_j[:3, :3] @ z
            p_j = T_j[:3, 3]
            OE = (com_position - p_j).reshape(1, -1)

            Jv[:, j, i] = np.cross(z_j, OE)
            Jw[:, j, i] = z_j


        # print(Jv[:,:,i])
    return Jv, Jw


def compute_mass_matrix(dh_params, inertial_params, q):
    n = len(q)
    M = np.zeros((n, n))

    # Extract center of mass positions
    com_positions = [inertial_params[i]['com'] for i in range(n)]

    Jv, Jw = compute_jacobians(dh_params, q, com_positions)

    for i in range(n):
        m_i = inertial_params[i]['mass']
        I_i = np.array([
            [inertial_params[i]['Ixx'], inertial_params[i]['Ixy'], inertial_params[i]['Ixz']],
            [inertial_params[i]['Ixy'], inertial_params[i]['Iyy'], inertial_params[i]['Iyz']],
            [inertial_params[i]['Ixz'], inertial_params[i]['Iyz'], inertial_params[i]['Izz']]
        ])
        Jv_i = Jv[:, :, i]
        Jw_i = Jw[:, :, i]

        M += m_i * Jv_i.T @ Jv_i + Jw_i.T @ I_i @ Jw_i

    return M


def GetC(q, q_dot):
    delta = 0.02
    Q = q.reshape(-1, 1)
    C = np.zeros((7, 1))

    TempC = 0
    for i in range(7):
        coef = np.zeros((7, 1))
        coef[i][0] = 1
        qmin = Q - delta * coef
        qmax = Q + delta * coef

        M_min = compute_mass_matrix(dh_params, inertial_params, qmin)
        M_max = compute_mass_matrix(dh_params, inertial_params, qmax)

        term1 = (q_dot.T @ M_max @ q_dot).item()
        term2 = (q_dot.T @ M_min @ q_dot).item()

        C[i][0] = -0.5 * (term1 - term2) / (2 * delta)

        # k = q_dot[i][0]
        TempC += (M_max - M_min) / (2 * delta) * q_dot[i][0]

    C = C + TempC @ q_dot
    return C


def GetG(dh_params, q, inertial_params):
    n = len(q)
    g = 9.81
    Q = np.array(q).reshape(-1, 1)

    com_positions = [inertial_params[i]['com'] for i in range(n)]

    # T = np.eye(4)  # Initial transformation matrix
    # T = T @ transformation_matrix(0, np.pi, 0, 0)
    delta = 0.02
    G = np.zeros((7, 1))

    for i in range(7):
        coef = np.zeros((7, 1))
        coef[i,0] = 1
        qmin = Q - delta * coef
        qmax = Q + delta * coef

        T_matrices_min = []
        T_matrices_max = []

        T_matrix_max_Shift = []
        T_matrix_min_Shift = []

        T_matrix_max_final = np.eye(4)
        T_matrix_min_final = np.eye(4)
        T_matrix_max_final[2, 3] = -0.13
        T_matrix_min_final[2, 3] = -0.13

        T_matrix_max_final = T_matrix_max_final @ transformation_matrix(0, np.pi, 0, 0)
        T_matrix_min_final = T_matrix_min_final @ transformation_matrix(0, np.pi, 0, 0)

        T_matrix_max_Shift.append(T_matrix_max_final)
        T_matrix_min_Shift.append(T_matrix_min_final)

        max_Z = []
        min_Z = []
        for j in range(n):
            a, alpha, d, theta = dh_params[j]
            theta_min = theta + qmin[j][0]
            theta_max = theta + qmax[j][0]

            T_j_min = transformation_matrix(a, alpha, d, theta_min)
            T_j_max = transformation_matrix(a, alpha, d, theta_max)

            T_matrix_max_final = T_matrix_max_final @ T_j_max
            T_matrix_min_final = T_matrix_min_final @ T_j_min

            max_Z.append(T_matrix_max_final[:3,:3] @ np.array(com_positions[j]).reshape(-1, 1) + T_matrix_max_final[:3,3].reshape(-1, 1))
            min_Z.append(T_matrix_min_final[:3,:3] @ np.array(com_positions[j]).reshape(-1, 1) + T_matrix_min_final[:3,3].reshape(-1, 1))

            T_matrices_min.append(T_matrix_min_final)
            T_matrices_max.append(T_matrix_max_final)

            T_matrix_max_Shift.append(T_matrix_max_final)
            T_matrix_min_Shift.append(T_matrix_min_final)

        Gmax = 0
        Gmin = 0
        for j in range(n):
            Gmax += T_matrices_max[j][2, 3] * inertial_params[j]['mass'] * g
            Gmin += T_matrices_min[j][2, 3] * inertial_params[j]['mass'] * g

            # Gmax += max_Z[j][2,0] * inertial_params[j]['mass'] * g
            # Gmin += min_Z[j][2,0] * inertial_params[j]['mass'] * g

            #
            # Gmax += T_matrix_max_Shift[j][2, 3] * inertial_params[j]['mass'] * g
            # Gmin += T_matrix_min_Shift[j][2, 3] * inertial_params[j]['mass'] * g

        G[i][0] = (Gmax - Gmin) / (2 * delta)

    return G




def example_send_joint_speeds(base, speeds):
    joint_speeds = Base_pb2.JointSpeeds()

    actuator_count = base.GetActuatorCount().count
    # The 7DOF robot will spin in the same direction for 10 seconds
    if actuator_count == 7:
        # speeds = [SPEED, 0, -SPEED, 0, SPEED, 0, -SPEED]
        i = 0
        for speed in speeds:
            joint_speed = joint_speeds.joint_speeds.add()
            joint_speed.joint_identifier = i
            joint_speed.value = speed.item()
            joint_speed.duration = 0
            i = i + 1
        # print("Sending the joint speeds for 10 seconds...")
        base.SendJointSpeedsCommand(joint_speeds)

    # print("Stopping the robot")
    # base.Stop()

    return True


def main():
    # Import the utilities helper module
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import utilities

    # Parse arguments
    args = utilities.parseConnectionArguments()

    # Create connection to the device and get the router
    with utilities.DeviceConnection.createTcpConnection(args) as router:
        # Create required services
        base = BaseClient(router)
        base_cyclic = BaseCyclicClient(router)
        traj = np.load("record.npy")
        traj = traj[:,20:-1]
        traj = np.hstack((traj,traj,traj,traj))
        # 用于读取轨迹
        counter = 0
        # 用于判断是否受力
        force = False
        while True:

            counter += 1
            if counter < traj.shape[1]:  # 确保不会越界
                pose = traj[:, counter].reshape(-1, 1)
            else:
                break

            # 获取数据
            data = base_cyclic.RefreshFeedback()
            q = np.zeros((7, 1))
            qd = np.zeros((7, 1))
            tor = np.zeros((7, 1))
            for j in range(7):
                q[j, 0] = data.actuators[j].position
                qd[j, 0] = data.actuators[j].velocity
                tor[j, 0] = data.actuators[j].torque


            q = np.deg2rad(q)
            qd = np.deg2rad(qd)
            tor = tor * np.array([1, -1, 1, -1, 1, -1, 1]).reshape(-1, 1) + np.array([0, 0, -0.6, 0, -1.3, 0, 1.6]).reshape(-1, 1)

            # qdd = (qd - q_dot_last) / (time.time() - lastTime)
            # q_dot_last = qd
            # lastTime = time.time()

            M = compute_mass_matrix(dh_params, inertial_params, q)
            C = GetC(q, qd)
            G = GetG(dh_params, q, inertial_params)
            kk = (tor - G - C)

            threshold = np.array([1, 1,1, 1, 1, 1, 1]).reshape(-1, 1)*3
            v = np.where(np.abs(kk) > threshold, kk, 0)

            # 只有当v大于阈值时，才会进行力控
            if np.linalg.norm(v) > 3:
                force = True
            else:
                force = False

            # 不受力时，执行原来的任务
            if not force:
                print(v.reshape(1,-1))

                q = np.rad2deg(q)

                qerror = q - pose
                speeds = -0.6 * normalization_to_neg_pos_pi(qerror)
            # 受力时，执行力控
            else:
                qdd = np.linalg.inv(M) @ v
                delta_T = 0.06
                qd_desired = qd + qdd * delta_T
                increment = qd_desired * delta_T
                q_desired = q + np.clip(increment, -0.1, 0.1)
                q = np.rad2deg(q)
                q_desired = np.rad2deg(q_desired)
                qd = np.rad2deg(qd)

                speed_diff = normalization_to_neg_pos_pi(q - q_desired)
                speeds = 0.8 * speed_diff * np.array([-0.45, 1.75, -1.8, 1.75, -0.8, 0.9, -1.75]).reshape(-1,1) + np.array([0.2, 0.1, 0, 0.6, 0, 0, 0.15]).reshape(-1, 1) * qd

                # Joint_speeds = np.clip(Joint_speeds, -10, 10)

            speeds = np.clip(speeds, -10, 10)
            # print(speeds)
            example_send_joint_speeds(base, speeds)
            # print(counter)


if __name__ == "__main__":
    exit(main())
